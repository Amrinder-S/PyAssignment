num=int(input("Enter a Number:"))
div=[]
for i in range(1,num//2):
    if(num%i==0):
        div.append(i)
div.append(num)
print("List of Divisors:",div)