import os
f=open("test.txt","x")
f.write("This is a New File.")
f.close()

f=open("test.txt","r")
print(f.read())
f.close()

f=open("test.txt","a")
f.write("This text was added later.")
f.close()

f=open("test.txt","r")
print(f.read())
f.close()

f=open("test.txt","w")
f.write("File Overwrite")
f.close()

f=open("test.txt","r")
print(f.read())
f.close()

os.remove("test.txt")
print("test.txt file exists:",os.path.exists("test.txt"))

