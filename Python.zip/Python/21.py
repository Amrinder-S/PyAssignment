a=int(input("Enter a Number:"))
b=int(input("Enter a Number:"))
if(a>b):
    print(a,"is Larger")
else:
    print(b,"is Larger")