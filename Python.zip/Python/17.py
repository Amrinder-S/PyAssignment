l=[]
a=int(input("Enter the length of list:"))
for i in range(0,a):
    l.append(input("Enter the element:"))
print("List:",l)