a=int(input())
b=int(input())
if((a<1)or(a>10**10)or(b<1)or(b>10**10)):
    print("Error!")
else:
    print(a+b)
    print(a-b)
    print(a*b)