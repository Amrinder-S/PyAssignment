a=int(input("Enter a Number:"))
if(a%2==0):
    print("Numer is Even")
else:
    print("Number is Odd")
if(a%4==0):
    print("Numer is Multiple of 4")
