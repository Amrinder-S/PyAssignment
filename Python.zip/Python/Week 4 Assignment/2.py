f=open("test2.txt","r")
print(f.read())
f.close()

f=open("test2.txt","a")
f.write("This text was added later.")
f.close()

f=open("test2.txt","r")
print(f.read())
f.close()