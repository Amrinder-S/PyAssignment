l=[1,2,3,4,5,6,7,8,9]
prime=[]
for i in l:
    flag=0
    for j in range(2,i):
        if(i%j==0):
            flag=1
            break
    
    if(flag==0 and i!=1):
        prime.append(i)
print(prime)