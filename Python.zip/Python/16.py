wlist=["Programmer","Truck Driver","Doctor","Electrician"]
print("Orignal List:",wlist)
print("Index of Doctor:",wlist.index("Doctor"))
print("List includes Electrician:","Electrician" in wlist)
wlist.append("Teacher")
print("List after append:",wlist)
wlist.insert(0,"CEO")
print("List after insertion:",wlist)
print("Careers:")
for i in range(0,len(wlist)):
    print(i+1,wlist[i])
