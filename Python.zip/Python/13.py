a=[1,1,2,3,5,8,13,21,34,55,89]
b=[]
n=int(input("Enter a number:"))
for i in range(0,len(a)):
    if(a[i]<n):
        b.append(a[i])
print("Orignal List:",a)
print("New List:",b)