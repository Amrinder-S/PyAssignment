import datetime
name=input("Enter Your Name:")
age=int(input("Enter Your Age:"))
print("Hello!",name)
print("You will turn 100 year old in",(datetime.datetime.now().year-age+100))