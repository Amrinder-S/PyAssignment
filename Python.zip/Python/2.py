str1 = 'Hello Python'  
print(str1)
str2 = "Hello Python"  
print(str2)  
str3 = '''''Triple quotes are generally used for  
        represent the multiline or 
        docstring'''   
print(str3) 
a=input("Enter:") 
print("Type of a:",type(a))
