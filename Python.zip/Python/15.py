l=['Python','C','java']
print(l[0],"is a high-level, interpreted programming language.")
print(l[1],"is a general-purpose computer programming language.")
print(l[2],"is used to develop mobile apps, web apps, desktop apps, games and much more.")