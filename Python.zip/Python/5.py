a=input("Enter String:")
print("Length of String=",len(a))