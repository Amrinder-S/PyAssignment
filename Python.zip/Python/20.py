List18=["Programmer","Truck Driver","Doctor","Electrician"]
List19=[5,6,1,3,2,4]
print("Length of List18:",len(List18))
print("Length of List19:",len(List19))
