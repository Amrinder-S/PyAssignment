n=1
sum=0
while(n<6):
    sum+=int(input("Enter marks of Subject "+str(n)+":"))
    n+=1
print("Average=",sum/5)
print("Percentage=",(sum/500)*100)