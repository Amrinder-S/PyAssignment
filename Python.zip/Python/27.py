def prin(a,b,c,res):
    x=str(a)+str(c)+str(b)+"="+str(res)+"\n"
    print(x)
    f=open("data.txt","a")
    f.write(x)
    f.close()

num1=int(input("Enter 1st Number:"))
num2=int(input("Enter 2nd Number:"))
op=input("Enter a operator(+,-,*,/):")
if(op=="+"):
    prin(num1,num2,op,num1+num2)
elif(op=="-"):
    prin(num1,num2,op,num1-num2)
elif(op=="*"):
    prin(num1,num2,op,num1*num2)
elif(op=="/"):
    prin(num1,num2,op,num1/num2)
else:
    print("Invaild Operator!")