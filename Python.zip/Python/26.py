def test(a , b):
	try:
		c = ((a+b) // (a-b))
	except ZeroDivisionError:
		print ("a-b results in 0")
	else:
		print(c)
  
test(5, 3)
test(3, 3)
try:
    print(x)
except NameError:
    print("x is not defined")
