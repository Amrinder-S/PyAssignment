str1=input("Enter the String 1:")
str2=input("Enter the String 2:")
str3=str1+" "+str2
str1a=str1.replace(str1[1],str1[0],1).replace(str1[0],str1[1],1)
str2a=str2.replace(str2[1],str2[0],1).replace(str2[0],str2[1],1)
str3a=str1a+" "+str2a
print("Orignal String 3:",str3)
print("Altered String 3:",str3a)