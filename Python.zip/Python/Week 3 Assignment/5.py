
from re import L

l=[]
n=int(input("Enter Length of List:"))
for i in range(0, n):
    x=input("Enter vlaue of "+str(i)+"th index:")
    l.append(x)
a=int(input("Enter the index of element to swap:"))
b=int(input("Enter the index of element to swap with:"))
print("Orignal List:",l)
l[a],l[b]=l[b],l[a]
print("Altered List:",l)