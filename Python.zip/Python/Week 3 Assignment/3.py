str0=input("Enter the String:")
half = int(len(str0)/ 2)

if len(str0) % 2 == 0:
	str1 = str0[:half]
	str2 = str0[half:]
else:
	str1 = str0[:half]
	str2 = str0[half+1:]

if str1 == str2:
	print('String is symmertical')
else:
	print('String is not symmertical')

if str1 == str2[::-1]:
	print('String is palindrome')
else:
	print('String is not palindrome')
