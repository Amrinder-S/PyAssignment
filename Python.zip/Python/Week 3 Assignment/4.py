l=[]
n=int(input("Enter Length of List:"))
for i in range(0, n):
    x=input("Enter vlaue of "+str(i)+"th index:")
    l.append(x)
print("Orignal List:",l)
l[0],l[len(l)-1]=l[len(l)-1],l[0]
print("Altered List:",l)
