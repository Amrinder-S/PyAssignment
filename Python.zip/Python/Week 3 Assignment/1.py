str1=input("Enter the string:")
str2= str1[0]+str1[1:].replace(str1[0], "$")
print("Orignal String:",str1)
print("Altered String:",str2)
