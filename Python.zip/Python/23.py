dict =	{
  "Brand": "Ford",
  "Model": "Mustang",
  "Year": 1964
}
print(dict)
print("Brand:",dict["Brand"])
print("Length of Dictionary:",len(dict))