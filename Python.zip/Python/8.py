import datetime
name=input("Enter Your Name:")
age=int(input("Enter Your Age:"))
x="Hello!"+name+" "+"You will turn 100 year old in "+str((datetime.datetime.now().year-age+100))
print(x)
n=int(input("Enter no. of replication:"))
print((x+" ")*n)